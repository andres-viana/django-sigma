from django.db import models
from django.conf import settings

import os

#create your models here!